import React, { useState, useEffect } from 'react';
import { getAllBookingsAdmin, cancelBooking } from '../../services/api';

function AdminBookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const response = await getAllBookingsAdmin();
      setBookings(response.data || []);
    } catch (err) {
      console.error('Error fetching bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredBookings = bookings.filter(b =>
    b.property?.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.user?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const cancelBookingHandler = async (id) => {
    if (window.confirm('Cancel this booking?')) {
      try {
        await cancelBooking(id);
        fetchBookings();
        alert('Booking cancelled');
      } catch (err) {
        alert('Failed to cancel booking');
      }
    }
  };

  const totalRevenue = bookings.filter(b => b.status === 'CONFIRMED').reduce((sum, b) => sum + (b.totalPrice || 0), 0);

  if (loading) {
    return <div style={{ padding: '32px', textAlign: 'center' }}>Loading bookings...</div>;
  }

  return (
    <div style={{ padding: '32px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: '32px', marginBottom: '8px' }}>Booking Management</h1>
          <p style={{ color: '#9A8F84' }}>Total Revenue: <strong style={{ color: '#C4622D' }}>${totalRevenue.toLocaleString()}</strong></p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <input type="text" placeholder="Search by property or guest..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={{ padding: '10px 16px', border: '1px solid #E8D5B7', borderRadius: '10px', width: '250px', outline: 'none' }} />
        </div>
      </div>

      <div style={{ background: 'white', borderRadius: '16px', border: '1px solid #E8D5B7', overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead style={{ background: '#FAF8F4', borderBottom: '1px solid #E8D5B7' }}>
            <tr>
              <th style={{ padding: '16px', textAlign: 'left' }}>Property</th>
              <th style={{ padding: '16px', textAlign: 'left' }}>Guest</th>
              <th style={{ padding: '16px', textAlign: 'left' }}>Dates</th>
              <th style={{ padding: '16px', textAlign: 'left' }}>Amount</th>
              <th style={{ padding: '16px', textAlign: 'left' }}>Status</th>
              <th style={{ padding: '16px', textAlign: 'left' }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredBookings.map(booking => (
              <tr key={booking.id} style={{ borderBottom: '1px solid #F0EAE0' }}>
                <td style={{ padding: '16px', fontWeight: 500 }}>{booking.property?.title || 'N/A'}</td>
                <td style={{ padding: '16px' }}>{booking.user?.name || 'N/A'}</td>
                <td style={{ padding: '16px', fontSize: '13px', color: '#666' }}>{booking.checkIn} → {booking.checkOut}</td>
                <td style={{ padding: '16px', fontWeight: 600, color: '#C4622D' }}>${booking.totalPrice}</td>
                <td style={{ padding: '16px' }}>
                  <span style={{ padding: '4px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: 500, background: booking.status === 'CONFIRMED' ? '#E8F5E9' : '#FFEBEE', color: booking.status === 'CONFIRMED' ? '#2E7D32' : '#C62828' }}>
                    {booking.status}
                  </span>
                </td>
                <td style={{ padding: '16px' }}>
                  {booking.status === 'CONFIRMED' && (
                    <button onClick={() => cancelBookingHandler(booking.id)} style={{ padding: '6px 12px', background: '#C62828', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontSize: '12px' }}>Cancel</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AdminBookings;